package com.fy.Demo;
/**
 * 封装了
 * @author 朱明爽
 * @date 上午11:51:32
 */

public class CHSR {
	private City sp;//定义变量城市
	private int level;//定义变量等级
	private double price;//定义变量价格
	public  City getSp() {
		return sp;
	}
	public void setSp(City sp) {
		this.sp = sp;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	//set和get就是用于设置和读取Java private变量的方法。这样子外部程序就不会直接访问程序的变量。
	//只能通过set去设置值，用get去读取值。有利于对外封装。防止外部程序随意修改我们的变量。
	public CHSR(){
		super();
		
		
	}
	public CHSR(City sp,int level){
		this.sp=sp;
		this.level=level;
	}
	

}
