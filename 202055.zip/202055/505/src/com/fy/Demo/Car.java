package com.fy.Demo;
/**
 * 封装类
 * @author 朱明爽
 * @date 下午2:12:55
 */

public class Car {

	public static void main(String[] args) {
		Car car=new Car("大众","保时捷",100000,150,200,600);
		car.showMessage();
		car.showRemain();
		System.out.println("剩余油量"+car.getRemainoil());
	}
  //品牌,车型,价格,油耗,公里数,油箱容积,剩余油量,
	private String brind;
	private  String  id;
	private double price;
	private double fuel;
	private double kilometer;
	private double volume;
	private double remainoil;
	public String getBrind() {
		return brind;
	}
	public void setBrind(String brind) {
		this.brind = brind;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getFuel() {
		return fuel;
	}
	public void setFuel(double fuel) {
		this.fuel = fuel;
	}
	public double getKilometer() {
		return kilometer;
	}
	public void setKilometer(double kilometer) {
		this.kilometer = kilometer;
	}
	public double getPvolume() {
		return volume;
	}
	public void setPvolume(double pvolume) {
		this.volume = pvolume;
	}
	public double getRemainoil() {
		return remainoil;
	}
	public void setRemainoil(double remainoil) {
		this.remainoil = remainoil;
	}
	 public Car(){
		 
	 }
	 public  Car (String brind,String id,double price,double fuel,double kilometer,double  volume){
		this.brind=brind;
		this.id=id;
		this.price=price;
		this.fuel=fuel;
		this.kilometer=kilometer;
		this.volume=volume;
		
		 
	}
	 //品牌，车型，价格，油耗，里程数，油箱容积，剩余油量
	 public void showMessage(){
		 System.out.println("车牌："+Car.this.brind+"\t"+"车型："+Car.this.id+"\t"+"价格："+Car.this.price+"\t"+"油耗："
	 +Car.this.fuel+"\t"+"里程数："+Car.this.kilometer+"\t"+"油箱容积："+Car.this.volume);
	 }
	 public  double showRemain(){
		 remainoil=Car.this.volume-(Car.this.kilometer/100*Car.this.fuel);
		 return  remainoil;
	 }
	}

