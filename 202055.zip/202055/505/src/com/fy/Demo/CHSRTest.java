package com.fy.Demo;

import org.omg.CORBA.DynAny;

public class CHSRTest {

	public static void main(String[] args) {
		int i=2;
		CHSR chsr=new CHSR(City.ZHENGJIANG,i);
		if (i>0&&i<3) {
			System.out.println("到达城市："+chsr.getSp()+"几等座："+i+"价格："+showPrice(chsr.getSp(),chsr.getLevel()));
		}else {
			System.out.println("请输入正确的等级");
		}
			
		}
   public static double showPrice (City s,int i) {
   double ticketprice=0;
  
    switch(s){
   case NANJING:
      break;
   case ZHENGJIANG:
     if(i==1){
    	 ticketprice=44.5;
     }else if(i==2){
		ticketprice=29.5;
	}
      break;
   case DANYANG:
   if(i==1){
  	ticketprice=64.5;
   }else if(i==2){
		ticketprice=39.5;
	}
    break;
   case CHANGZHOU:
   if(i==1){
  	 ticketprice=99.5;
   }else if(i==2){
		ticketprice=64.5;
	}
    break;
   case WUXI:
   if(i==1){
  	 ticketprice=129.5;
   }else if(i==2){
		ticketprice=79.5;
	}
    break;
   case SUZHOU:
   if(i==1){
  	 ticketprice=159.5;
   }else if(i==2){
	   ticketprice=99.5;
	}
    break;
   case SHANGHAI:
   if(i==1){
  	 ticketprice=219.5;
   }else if(i==2){
		ticketprice=139.5;
	}
    break;
	
}
	return  ticketprice;

}}
