package com.fy.Demo;

public enum City {
	NANJING,ZHENGJIANG,DANYANG,CHANGZHOU,WUXI,SUZHOU,SHANGHAI
	

}
